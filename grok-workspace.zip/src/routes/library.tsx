import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Chip } from "@/components/music";
import { usePlayer } from "@/lib/player-store";

export const Route = createFileRoute("/library")({ component: LibraryPage });

function LibraryPage() {
  const [tab, setTab] = useState<"listas" | "gustan">("listas");
  const playlists = usePlayer((s) => s.playlists);
  const liked = usePlayer((s) => s.liked);

  return (
    <div>
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">Biblioteca</h1>
        <button type="button" onClick={() => usePlayer.getState().openCreator()} className="h-10 rounded-full bg-fg px-4 text-sm font-medium text-bg">
          Nueva lista
        </button>
      </div>
      <div className="mt-4 flex gap-2">
        <Chip active={tab === "listas"} onClick={() => setTab("listas")}>Listas</Chip>
        <Chip active={tab === "gustan"} onClick={() => setTab("gustan")}>Me gusta · {liked.length}</Chip>
      </div>
      {tab === "listas" ? (
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          <LibraryCard id="likes" title="Canciones que te gustan" cover="/covers/likes.svg" meta={`${liked.length} canciones`} />
          <LibraryCard id="recents" title="Escuchadas hace poco" cover="/covers/recents.svg" meta="Tu historial" />
          {playlists.map((playlist) => (
            <LibraryCard key={playlist.id} id={playlist.id} title={playlist.name} cover="/covers/voces.svg" meta={`${playlist.trackIds.length} canciones`} />
          ))}
        </div>
      ) : liked.length === 0 ? (
        <p className="mt-8 max-w-sm text-sm text-muted">Todavía no marcaste ninguna. Toca el corazón en un himno y queda aquí.</p>
      ) : (
        <Link to="/playlist/$playlistId" params={{ playlistId: "likes" }} className="mt-6 flex items-center gap-4 rounded-xl bg-surface p-4">
          <img src="/covers/likes.svg" alt="" className="size-16 rounded-md" />
          <span>
            <span className="block font-medium">Tus me gusta</span>
            <span className="text-sm text-muted">{liked.length} canciones</span>
          </span>
        </Link>
      )}
    </div>
  );
}

function LibraryCard({ id, title, cover, meta }: { id: string; title: string; cover: string; meta: string }) {
  return (
    <Link to="/playlist/$playlistId" params={{ playlistId: id }} className="rounded-lg bg-surface p-3">
      <img src={cover} alt="" className="aspect-square w-full rounded-md object-cover" />
      <p className="mt-2 truncate text-sm font-medium">{title}</p>
      <p className="truncate text-xs text-muted">{meta}</p>
    </Link>
  );
}
