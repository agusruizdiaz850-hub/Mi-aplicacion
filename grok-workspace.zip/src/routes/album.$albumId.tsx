import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro, TrackList } from "@/components/music";
import { albumById, artistById } from "@/data/catalog";
import { usePlayer } from "@/lib/player-store";

export const Route = createFileRoute("/album/$albumId")({ component: AlbumPage });

function AlbumPage() {
  const { albumId } = Route.useParams();
  const album = albumById(albumId);
  const playing = usePlayer((s) => s.playing);
  const current = usePlayer((s) => s.queue[s.index]);
  if (!album) return <p className="mt-10 text-muted">No encontramos ese álbum.</p>;
  const artist = artistById(album.artistId);
  const active = album.trackIds.includes(current ?? "");

  return (
    <div>
      <PageIntro
        cover={album.cover}
        eyebrow="Álbum"
        title={album.title}
        subtitle={`${artist?.name ?? "Artista"} · ${album.year} · ${album.trackIds.length} canciones. ${album.description}`}
        playing={active && playing}
        onPlay={() => (active ? usePlayer.getState().toggle() : usePlayer.getState().playTracks(album.trackIds))}
      />
      {artist ? (
        <Link to="/artist/$artistId" params={{ artistId: artist.id }} className="mt-4 inline-block text-sm text-muted">
          Ver artista
        </Link>
      ) : null}
      <TrackList ids={album.trackIds} />
    </div>
  );
}
