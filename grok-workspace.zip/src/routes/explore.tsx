import { createFileRoute, Link } from "@tanstack/react-router";
import { AlbumCard, HScroll, MixCard, Section } from "@/components/music";
import { albums, artists, mixes } from "@/data/catalog";

export const Route = createFileRoute("/explore")({ component: Explore });

function Explore() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Explorar</h1>
      <p className="mt-1 text-sm text-muted">Adoración, calma y navidad. Todo cristiano, nada de catálogo comercial.</p>
      <Section title="Estados de ánimo">
        <HScroll>
          {mixes.map((mix) => (
            <MixCard key={mix.id} {...mix} mixId={mix.id} />
          ))}
        </HScroll>
      </Section>
      <Section title="Álbumes">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {albums.map((album) => (
            <AlbumCard key={album.id} albumId={album.id} />
          ))}
        </div>
      </Section>
      <Section title="Artistas">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
          {artists.map((artist) => (
            <Link key={artist.id} to="/artist/$artistId" params={{ artistId: artist.id }} className="rounded-xl bg-surface p-4">
              <img src={artist.cover} alt="" className="aspect-square w-full rounded-full object-cover" />
              <p className="mt-3 text-center font-medium">{artist.name}</p>
            </Link>
          ))}
        </div>
      </Section>
    </div>
  );
}
