import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AlbumCard, Chip, HScroll, MixCard, Section, TrackList } from "@/components/music";
import { albums, artists, mixes, tracks, type Mood } from "@/data/catalog";
import { usePlayer } from "@/lib/player-store";

export const Route = createFileRoute("/")({ component: Home });

const chips: { id: "todo" | Mood; label: string }[] = [
  { id: "todo", label: "Todo" },
  { id: "alabanza", label: "Alabanza" },
  { id: "calma", label: "Calma" },
  { id: "navidad", label: "Navidad" },
];

function Home() {
  const [hello, setHello] = useState("Hola");
  const [chip, setChip] = useState<(typeof chips)[number]["id"]>("todo");
  const recents = usePlayer((s) => s.recents);

  useEffect(() => {
    const hour = new Date().getHours();
    setHello(hour < 12 ? "Buenos días" : hour < 19 ? "Buenas tardes" : "Buenas noches");
  }, []);

  const filtered = chip === "todo" ? [] : tracks.filter((track) => track.mood === chip).map((track) => track.id);

  return (
    <div>
      <h1 className="text-2xl font-bold">{hello}</h1>
      <div className="hide-scroll mt-4 flex gap-2 overflow-x-auto">
        {chips.map((item) => (
          <Chip key={item.id} active={chip === item.id} onClick={() => setChip(item.id)}>
            {item.label}
          </Chip>
        ))}
      </div>

      {chip !== "todo" ? (
        <section className="mt-6">
          <div className="mb-2 flex items-center justify-between">
            <h2 className="text-xl font-bold">{chips.find((item) => item.id === chip)?.label}</h2>
            <button
              type="button"
              onClick={() => usePlayer.getState().playTracks(filtered)}
              className="h-10 rounded-full bg-fg px-4 text-sm font-medium text-bg"
            >
              Reproducir
            </button>
          </div>
          <TrackList ids={filtered} showCover />
        </section>
      ) : (
        <>
          <Section title={recents.length ? "Escuchar de nuevo" : "Para empezar"}>
            {recents.length ? (
              <TrackList ids={recents.slice(0, 6)} numbered={false} showCover />
            ) : (
              <HScroll>
                {mixes.slice(0, 3).map((mix) => (
                  <MixCard key={mix.id} {...mix} mixId={mix.id} />
                ))}
              </HScroll>
            )}
          </Section>

          <Section title="Mixes para ti">
            <HScroll>
              {mixes.map((mix) => (
                <MixCard key={mix.id} {...mix} mixId={mix.id} />
              ))}
            </HScroll>
          </Section>

          <Section title="Himnos" action={<Link to="/explore" className="text-sm text-muted">Ver todo</Link>}>
            <HScroll>
              {albums
                .filter((album) => album.artistId === "voces")
                .map((album) => (
                  <AlbumCard key={album.id} albumId={album.id} />
                ))}
            </HScroll>
          </Section>

          <Section title="Villancicos y adviento">
            <HScroll>
              {albums
                .filter((album) => album.artistId === "coro")
                .map((album) => (
                  <AlbumCard key={album.id} albumId={album.id} />
                ))}
            </HScroll>
          </Section>

          <Section title="Artistas">
            <HScroll>
              {artists.map((artist) => (
                <Link key={artist.id} to="/artist/$artistId" params={{ artistId: artist.id }} className="w-36 shrink-0 text-center md:w-40">
                  <img src={artist.cover} alt="" className="aspect-square w-full rounded-full bg-elevated object-cover" />
                  <p className="mt-2 truncate text-sm font-medium">{artist.name}</p>
                  <p className="text-xs text-muted">Artista</p>
                </Link>
              ))}
            </HScroll>
          </Section>

          <p className="mt-10 max-w-xl text-xs text-pretty text-muted">
            Himnos y villancicos de dominio público, cantados por voluntarios de LibriVox y servidos desde Internet Archive.
          </p>
        </>
      )}
    </div>
  );
}
