import { createFileRoute } from "@tanstack/react-router";
import { AlbumCard, HScroll, PageIntro, TrackList } from "@/components/music";
import { artistAlbums, artistById, tracks } from "@/data/catalog";
import { usePlayer } from "@/lib/player-store";

export const Route = createFileRoute("/artist/$artistId")({ component: ArtistPage });

function ArtistPage() {
  const { artistId } = Route.useParams();
  const artist = artistById(artistId);
  const albums = artistAlbums(artistId);
  const popular = tracks.filter((track) => track.artistId === artistId).map((track) => track.id);
  const playing = usePlayer((s) => s.playing);
  const current = usePlayer((s) => s.queue[s.index]);
  if (!artist) return <p className="mt-10 text-muted">No encontramos a ese artista.</p>;
  const active = popular.includes(current ?? "");

  return (
    <div>
      <PageIntro
        cover={artist.cover}
        eyebrow="Artista"
        title={artist.name}
        subtitle={artist.blurb}
        playing={active && playing}
        onPlay={() => (active ? usePlayer.getState().toggle() : usePlayer.getState().playTracks(popular))}
      />
      <h2 className="mt-8 text-xl font-bold">Popular</h2>
      <TrackList ids={popular.slice(0, 8)} showCover />
      <h2 className="mt-8 mb-3 text-xl font-bold">Álbumes</h2>
      <HScroll>
        {albums.map((album) => (
          <AlbumCard key={album.id} albumId={album.id} />
        ))}
      </HScroll>
    </div>
  );
}
