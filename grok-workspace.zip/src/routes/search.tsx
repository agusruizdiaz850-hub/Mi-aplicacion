import { createFileRoute, Link } from "@tanstack/react-router";
import { AlbumCard, TrackList } from "@/components/music";
import { mixes, searchCatalog } from "@/data/catalog";

export const Route = createFileRoute("/search")({
  validateSearch: (search: Record<string, unknown>) => ({
    q: typeof search.q === "string" ? search.q : "",
  }),
  component: SearchPage,
});

function SearchPage() {
  const { q } = Route.useSearch();
  const result = searchCatalog(q);

  if (!q.trim()) {
    return (
      <div>
        <h1 className="text-2xl font-bold">Buscar</h1>
        <p className="mt-1 text-sm text-muted">Prueba con gracia, navidad, paz o Emanuel.</p>
        <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-3">
          {mixes.map((mix) => (
            <Link key={mix.id} to="/playlist/$playlistId" params={{ playlistId: mix.id }} className="relative h-28 overflow-hidden rounded-xl">
              <img src={mix.cover} alt="" className="h-full w-full object-cover" />
              <span className="absolute inset-0 bg-bg/40" />
              <span className="absolute bottom-3 left-3 font-medium">{mix.title}</span>
            </Link>
          ))}
        </div>
      </div>
    );
  }

  const empty = result.tracks.length + result.albums.length + result.artists.length === 0;

  return (
    <div>
      <h1 className="text-2xl font-bold">Resultados</h1>
      <p className="mt-1 text-sm text-muted">“{q}”</p>
      {empty ? <p className="mt-8 text-sm text-muted">Nada con ese nombre. Prueba “gracia” o “belén”.</p> : null}
      {result.tracks.length ? (
        <section className="mt-6">
          <h2 className="text-lg font-bold">Canciones</h2>
          <TrackList ids={result.tracks.map((track) => track.id)} showCover />
        </section>
      ) : null}
      {result.albums.length ? (
        <section className="mt-6">
          <h2 className="mb-3 text-lg font-bold">Álbumes</h2>
          <div className="flex gap-3 overflow-x-auto">
            {result.albums.map((album) => (
              <AlbumCard key={album.id} albumId={album.id} />
            ))}
          </div>
        </section>
      ) : null}
      {result.artists.length ? (
        <section className="mt-6">
          <h2 className="mb-3 text-lg font-bold">Artistas</h2>
          <div className="flex gap-4">
            {result.artists.map((artist) => (
              <Link key={artist.id} to="/artist/$artistId" params={{ artistId: artist.id }} className="w-32 text-center">
                <img src={artist.cover} alt="" className="aspect-square w-full rounded-full object-cover" />
                <p className="mt-2 text-sm font-medium">{artist.name}</p>
              </Link>
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}
