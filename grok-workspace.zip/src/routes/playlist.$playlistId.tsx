import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageIntro, TrackList } from "@/components/music";
import { mixById, tracksOf } from "@/data/catalog";
import { usePlayer } from "@/lib/player-store";

export const Route = createFileRoute("/playlist/$playlistId")({ component: PlaylistPage });

function PlaylistPage() {
  const { playlistId } = Route.useParams();
  const liked = usePlayer((s) => s.liked);
  const recents = usePlayer((s) => s.recents);
  const playlists = usePlayer((s) => s.playlists);
  const user = playlists.find((playlist) => playlist.id === playlistId);
  const mix = mixById(playlistId);
  const playing = usePlayer((s) => s.playing);
  const current = usePlayer((s) => s.queue[s.index]);
  const [confirm, setConfirm] = useState(false);
  const [renaming, setRenaming] = useState(false);
  const [name, setName] = useState("");

  const special =
    playlistId === "likes"
      ? { title: "Canciones que te gustan", subtitle: "Lo que marcaste con el corazón.", cover: "/covers/likes.svg", ids: liked, owned: false }
      : playlistId === "recents"
        ? { title: "Escuchadas hace poco", subtitle: "Lo último que sonó en este dispositivo.", cover: "/covers/recents.svg", ids: recents, owned: false }
        : user
          ? { title: user.name, subtitle: "Tu lista, guardada en este dispositivo.", cover: "/covers/voces.svg", ids: user.trackIds, owned: true }
          : mix
            ? { title: mix.title, subtitle: mix.subtitle, cover: mix.cover, ids: mix.trackIds, owned: false }
            : null;

  if (!special) return <p className="mt-10 text-muted">No encontramos esa lista.</p>;
  const active = special.ids.includes(current ?? "");

  return (
    <div>
      <PageIntro
        cover={special.cover}
        eyebrow="Lista"
        title={special.title}
        subtitle={`${special.subtitle} ${tracksOf(special.ids).length} canciones.`}
        playing={active && playing && special.ids.length > 0}
        onPlay={() => {
          if (!special.ids.length) return;
          if (active) usePlayer.getState().toggle();
          else usePlayer.getState().playTracks(special.ids);
        }}
      />
      {special.owned && user ? (
        <div className="mt-4 flex gap-2">
          <button
            type="button"
            onClick={() => {
              setName(user.name);
              setRenaming(true);
            }}
            className="h-10 rounded-full bg-elevated px-4 text-sm"
          >
            Renombrar
          </button>
          <button type="button" onClick={() => setConfirm(true)} className="h-10 rounded-full bg-elevated px-4 text-sm text-accent">
            Eliminar
          </button>
        </div>
      ) : null}
      {renaming && user ? (
        <form
          className="mt-3 flex gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            usePlayer.getState().renamePlaylist(user.id, name);
            setRenaming(false);
          }}
        >
          <input value={name} onChange={(event) => setName(event.target.value)} className="h-10 flex-1 rounded-md bg-elevated px-3 text-sm outline-none" />
          <button type="submit" className="h-10 rounded-full bg-fg px-4 text-sm text-bg">Guardar</button>
        </form>
      ) : null}
      {confirm && user ? (
        <div className="mt-3 flex items-center gap-2 text-sm">
          <span>¿Eliminar “{user.name}”?</span>
          <button
            type="button"
            className="h-9 rounded-full bg-accent px-3 text-fg"
            onClick={() => {
              usePlayer.getState().deletePlaylist(user.id);
              window.history.back();
            }}
          >
            Sí, eliminar
          </button>
          <button type="button" className="h-9 rounded-full px-3 text-muted" onClick={() => setConfirm(false)}>
            No
          </button>
        </div>
      ) : null}
      {special.ids.length === 0 ? (
        <p className="mt-8 text-sm text-muted">Esta lista está vacía. Añade canciones desde el menú de tres puntos.</p>
      ) : (
        <TrackList
          ids={special.ids}
          showCover
          onRemove={
            special.owned && user
              ? (id) => usePlayer.getState().removeFromPlaylist(user.id, id)
              : undefined
          }
        />
      )}
    </div>
  );
}
