import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { toast } from "sonner";
import { trackById } from "@/data/catalog";

export type RepeatMode = "off" | "all" | "one";

export type UserPlaylist = {
  id: string;
  name: string;
  trackIds: string[];
};

type Creator = { open: boolean; trackId?: string };

type PlayerState = {
  queue: string[];
  index: number;
  playing: boolean;
  progress: number;
  duration: number;
  volume: number;
  muted: boolean;
  shuffle: boolean;
  repeat: RepeatMode;
  liked: string[];
  recents: string[];
  playlists: UserPlaylist[];
  queueOpen: boolean;
  nowOpen: boolean;
  nowTab: "cola" | "letra";
  seekNonce: number;
  creator: Creator;
  playTracks: (ids: string[], startId?: string) => void;
  toggle: () => void;
  next: () => void;
  prev: () => void;
  seek: (time: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  cycleRepeat: () => void;
  toggleLike: (id: string) => void;
  toggleQueue: () => void;
  setNowOpen: (open: boolean) => void;
  setNowTab: (tab: "cola" | "letra") => void;
  jumpTo: (index: number) => void;
  removeFromQueue: (index: number) => void;
  playNext: (id: string) => void;
  enqueue: (id: string) => void;
  openCreator: (trackId?: string) => void;
  closeCreator: () => void;
  createPlaylist: (name: string) => void;
  addToPlaylist: (playlistId: string, trackId: string) => void;
  removeFromPlaylist: (playlistId: string, trackId: string) => void;
  deletePlaylist: (playlistId: string) => void;
  renamePlaylist: (playlistId: string, name: string) => void;
};

let audio: HTMLAudioElement | null = null;
let failStreak = 0;
let loadToken = 0;

export function bindAudio(el: HTMLAudioElement | null) {
  audio = el;
}

function shuffleIds(ids: string[], first?: string) {
  const rest = ids.filter((id) => id !== first);
  for (let i = rest.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const swap = rest[i];
    rest[i] = rest[j]!;
    rest[j] = swap!;
  }
  return first ? [first, ...rest] : rest;
}

function remember(recents: string[], id: string) {
  return [id, ...recents.filter((item) => item !== id)].slice(0, 24);
}

const memory: Record<string, string> = {};
const storage = {
  getItem: (key: string) => (typeof window === "undefined" ? (memory[key] ?? null) : localStorage.getItem(key)),
  setItem: (key: string, value: string) => {
    if (typeof window === "undefined") memory[key] = value;
    else localStorage.setItem(key, value);
  },
  removeItem: (key: string) => {
    if (typeof window === "undefined") delete memory[key];
    else localStorage.removeItem(key);
  },
};

export const usePlayer = create<PlayerState>()(
  persist(
    (set, get) => ({
      queue: [],
      index: 0,
      playing: false,
      progress: 0,
      duration: 0,
      volume: 0.9,
      muted: false,
      shuffle: false,
      repeat: "off",
      liked: [],
      recents: [],
      playlists: [],
      queueOpen: false,
      nowOpen: false,
      nowTab: "letra",
      seekNonce: 0,
      creator: { open: false },
      playTracks: (ids, startId) => {
        const clean = ids.filter((id) => trackById(id));
        const start = startId && clean.includes(startId) ? startId : clean[0];
        if (!start) return;
        failStreak = 0;
        const queue = get().shuffle ? shuffleIds(clean, start) : clean;
        const index = Math.max(0, queue.indexOf(start));
        set({ queue, index, playing: true, progress: 0, recents: remember(get().recents, start) });
      },
      toggle: () => {
        const { queue, playing } = get();
        if (!queue.length) return;
        set({ playing: !playing });
      },
      next: () => {
        const { index, queue, repeat } = get();
        if (!queue.length) return;
        if (index < queue.length - 1) {
          const id = queue[index + 1]!;
          set({ index: index + 1, progress: 0, playing: true, recents: remember(get().recents, id) });
          return;
        }
        if (repeat === "all") {
          const id = queue[0]!;
          set({ index: 0, progress: 0, playing: true, recents: remember(get().recents, id) });
          return;
        }
        set({ playing: false, progress: 0 });
      },
      prev: () => {
        const { index, progress, seekNonce, queue } = get();
        if (progress > 3 || index === 0) {
          set({ progress: 0, seekNonce: seekNonce + 1, playing: queue.length > 0 });
          return;
        }
        const id = queue[index - 1]!;
        set({ index: index - 1, progress: 0, playing: true, recents: remember(get().recents, id) });
      },
      seek: (time) => {
        const duration = get().duration || trackById(get().queue[get().index])?.duration || 0;
        const nextTime = Math.min(Math.max(0, time), duration || time);
        set({ progress: nextTime, seekNonce: get().seekNonce + 1 });
      },
      setVolume: (volume) => set({ volume: Math.min(1, Math.max(0, volume)), muted: volume === 0 }),
      toggleMute: () => set({ muted: !get().muted }),
      toggleShuffle: () => {
        const { shuffle, queue, index } = get();
        if (shuffle) {
          set({ shuffle: false });
          return;
        }
        const current = queue[index];
        const rest = queue.filter((_, i) => i !== index);
        set({
          shuffle: true,
          queue: current ? [current, ...shuffleIds(rest)] : shuffleIds(queue),
          index: 0,
        });
      },
      cycleRepeat: () => {
        const order: RepeatMode[] = ["off", "all", "one"];
        const nextMode = order[(order.indexOf(get().repeat) + 1) % order.length]!;
        set({ repeat: nextMode });
      },
      toggleLike: (id) => {
        const liked = get().liked.includes(id) ? get().liked.filter((item) => item !== id) : [id, ...get().liked];
        set({ liked });
      },
      toggleQueue: () => set({ queueOpen: !get().queueOpen }),
      setNowOpen: (open) => set({ nowOpen: open }),
      setNowTab: (tab) => set({ nowTab: tab }),
      jumpTo: (index) => {
        const id = get().queue[index];
        if (!id) return;
        set({ index, progress: 0, playing: true, recents: remember(get().recents, id) });
      },
      removeFromQueue: (at) => {
        const { queue, index } = get();
        const nextQueue = queue.filter((_, i) => i !== at);
        let nextIndex = index;
        if (at < index) nextIndex -= 1;
        if (at === index) nextIndex = Math.min(index, Math.max(0, nextQueue.length - 1));
        set({
          queue: nextQueue,
          index: nextIndex,
          playing: nextQueue.length > 0 && (at === index ? true : get().playing),
        });
      },
      playNext: (id) => {
        if (!trackById(id)) return;
        const { queue, index } = get();
        if (!queue.length) {
          get().playTracks([id]);
          return;
        }
        const nextQueue = [...queue];
        nextQueue.splice(index + 1, 0, id);
        set({ queue: nextQueue });
        toast("Sonará a continuación");
      },
      enqueue: (id) => {
        if (!trackById(id)) return;
        const { queue } = get();
        if (!queue.length) {
          get().playTracks([id]);
          return;
        }
        set({ queue: [...queue, id] });
        toast("Añadida a la cola");
      },
      openCreator: (trackId) => set({ creator: { open: true, trackId } }),
      closeCreator: () => set({ creator: { open: false } }),
      createPlaylist: (name) => {
        const title = name.trim();
        if (!title) return;
        const id = `p_${crypto.randomUUID().slice(0, 8)}`;
        const trackId = get().creator.trackId;
        set({
          playlists: [{ id, name: title, trackIds: trackId ? [trackId] : [] }, ...get().playlists],
          creator: { open: false },
        });
        toast(trackId ? "Lista creada y canción añadida" : "Lista creada");
      },
      addToPlaylist: (playlistId, trackId) => {
        set({
          playlists: get().playlists.map((playlist) => {
            if (playlist.id !== playlistId) return playlist;
            if (playlist.trackIds.includes(trackId)) return playlist;
            return { ...playlist, trackIds: [...playlist.trackIds, trackId] };
          }),
        });
        toast("Añadida a tu lista");
      },
      removeFromPlaylist: (playlistId, trackId) => {
        set({
          playlists: get().playlists.map((playlist) =>
            playlist.id === playlistId
              ? { ...playlist, trackIds: playlist.trackIds.filter((id) => id !== trackId) }
              : playlist,
          ),
        });
      },
      deletePlaylist: (playlistId) => {
        set({ playlists: get().playlists.filter((playlist) => playlist.id !== playlistId) });
      },
      renamePlaylist: (playlistId, name) => {
        const title = name.trim();
        if (!title) return;
        set({
          playlists: get().playlists.map((playlist) =>
            playlist.id === playlistId ? { ...playlist, name: title } : playlist,
          ),
        });
      },
    }),
    {
      name: "gracia-player",
      storage: createJSONStorage(() => storage),
      partialize: (state) => ({
        volume: state.volume,
        muted: state.muted,
        shuffle: state.shuffle,
        repeat: state.repeat,
        liked: state.liked,
        recents: state.recents,
        playlists: state.playlists,
        queue: state.queue,
        index: state.index,
      }),
    },
  ),
);

export function handleEnded() {
  const { repeat, index, queue } = usePlayer.getState();
  if (repeat === "one" && audio) {
    audio.currentTime = 0;
    void audio.play();
    return;
  }
  if (index < queue.length - 1 || repeat === "all") {
    usePlayer.getState().next();
    return;
  }
  usePlayer.setState({ playing: false, progress: 0 });
}

export function handleAudioError(token?: number) {
  if (token !== undefined && token !== loadToken) return;
  failStreak += 1;
  if (failStreak >= 3) {
    usePlayer.setState({ playing: false });
    toast.error("No se pudo reproducir. Revisa la conexión e inténtalo de nuevo.");
    return;
  }
  toast.error("Esta grabación no cargó. Pasando a la siguiente.");
  usePlayer.getState().next();
}

export function syncAudio(prev: PlayerState, next: PlayerState) {
  if (!audio) return;
  const id = next.queue[next.index];
  const prevId = prev.queue[prev.index];
  if (id && audio.dataset.track !== id) {
    const track = trackById(id);
    if (track) {
      loadToken += 1;
      audio.dataset.token = String(loadToken);
      audio.src = track.src;
      audio.dataset.track = id;
    }
  }
  audio.volume = next.muted ? 0 : next.volume;
  if (next.seekNonce !== prev.seekNonce) audio.currentTime = next.progress;
  const trackChanged = id !== prevId;
  if (next.playing !== prev.playing || trackChanged) {
    if (next.playing && id) {
      void audio.play().catch(() => {
        usePlayer.setState({ playing: false });
      });
    } else if (!next.playing) {
      audio.pause();
    }
  }
}
